"""Main module for pyssim."""

from __future__ import absolute_import

from ssim.ssimlib import main

if __name__ == '__main__':
    main()
